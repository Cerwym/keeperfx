﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace KfxModStudio.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
}
